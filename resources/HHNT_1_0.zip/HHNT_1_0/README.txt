READ ME:
*********

This software is developed and copyrighted by HIOX Softwares.
This is given under The GNU General Public License (GPL).
This version is HHNT 1.0


Features:
==========
a)HIOX Horizontal NEWS TICKER enables users to have numerous text links scroll as news.
b)Text with links can be given in a seperate text file.
c)The speed can be dynamically controlled.
d)The width, height and speed of scrolling can be controlled.
e)The text stops scrolling when mouse is moved over.
f)Color, Look and Feel are configurable.
g)Ease of use.


Installation:
=============
Please take 5 minutes time and read installation instructions carefully and
completely! This will ensure a proper and easy installation.

a) Unzip HHNT_1_0.zip to extract the files to the folder HHNT_1_0\HHNT_1_0

File Permissions:
 a) Give read and execute (644) permission for news.txt and colors.txt (Only of
Linux users).

Add/Edit News:
 a) Open the file HHNT_1_0/news.txt
 b) Add or edit the news in the same format already given in the file.

Configuring the Look and Feel:
 a) Open the file HHNT_1_0/colors.txt.
 b) Change the following code to change the particular fields
       background-color="#887788"
       font-color="#ffffff"
       scrolldelay="40"

Embedding the code:
 a) Open the file HHNT_1_0/code.txt in a browser
 b) Copy the code in the text box given.
 c) Paste the code any where needed.

Reporting:
  If you have any issues with the code. Please open the HHNT_1_0/about.php page
in the browser and click on the option Report, to go to feedback page of
Hscripts.com to give feedback

What you can do for us:
  If you use HIOX Software’s free scripts or any portion of the code, a link to
Hscripts.com will be on your website. We believe it is a fair trade for a free
script/code. Please don’t remove the link. It will of great help to us.


Releases:
=========
Release Date HHNT 1.0 : 02-11-2007

On any suggestions, mail to us at support@hscripts.com

Visit us at http://www.hscripts.com
Visit us at http://www.hiox.com
