
<!-- Welcome to the scripts database of HIOX INDIA      -->
<!-- This tool is developed and a copyright             -->
<!-- product of HIOX INDIA.			        -->
<!-- For more information visit http://www.hscripts.com -->

<html>
  <head>
     <style>
        .ta{background-color: ffff44;}
        .rad{color:red; font-weight:bold; background-color: ffff44;}
        .head{font-size: 22px; height: 60px; border: 1px solid #99bbff; background-color: dddddd; color: #3377ff; font-family: verdana, arial, san-serif;}
        .links{font-size: 14px; color: green; font-family: verdana, arial, san-serif; text-decoration:none;}
        .maintext{font-size: 13px; color: #fefefe; font-family: verdana, arial, san-serif; padding:20px;}
     </style>
  </head>

  <body bgcolor=#efefef style="margin: 0px;">
       <table width=75% height=100% bgcolor=#aaccff cellpadding=0 cellspacing=0 align=center>
           <tr><td align=center class=head>
                          HIOX Horizontal News Ticker
		</td></tr>
	   <tr align=center><td valign=top>
	   <a class=links href="code.php">Get Code</a>&nbsp;|&nbsp;
	   <a class=links href="readme.php">Instruction</a>&nbsp;|&nbsp;
	   <a class=links href="about.php">About Us</a>&nbsp;|&nbsp;
	   <a class=links target="blank" href="http://www.hscripts.com/support.php">Report</a><br>
	   </td></tr>
           <tr>
